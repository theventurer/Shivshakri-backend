const express = require("express");
const {
  requestOTP,
  verifyOTP,
  logoutUser,
  authMiddleware,
} = require("../../controllers/auth/auth-controller");

const router = express.Router();

// Request OTP (for both login and registration)
router.post("/request-otp", requestOTP);

// Verify OTP (for both login and registration)
router.post("/verify-otp", verifyOTP);

// Logout user
router.post("/logout", logoutUser);

// Check authentication status
router.get("/check-auth", authMiddleware, (req, res) => {
  res.status(200).json({
    success: true,
    message: "Authenticated user!",
    user: req.user,
  });
});

module.exports = router;