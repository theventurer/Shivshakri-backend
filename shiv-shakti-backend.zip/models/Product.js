const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema(
  {
    images: [String], // Array of image URLs
    videoUrls: [String], // Array of video URLs
    title: String,
    description: String,
    category: String,
    brand: String,
    price: Number,
    salePrice: Number,
    totalStock: Number,
    averageReview: Number,
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Product", ProductSchema);
