const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  userName: {
    type: String,
    required: true,
  },
  mobileNumber: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  email: {
    type: String,
    unique: true,
    sparse: true, // Allows null/undefined while maintaining uniqueness
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  otp: {
    type: String,
  },
  otpExpiry: {
    type: Date,
  },
  role: {
    type: String,
    default: "user",
  },
}, { timestamps: true });

// Indexes for faster queries
UserSchema.index({ mobileNumber: 1 });
UserSchema.index({ email: 1 });

const User = mongoose.model("User", UserSchema);
module.exports = User;