const Product = require("../../models/Product");

const searchProducts = async (req, res) => {
  try {
    const { keyword } = req.params;

    // Validate the keyword input
    if (!keyword || typeof keyword !== "string") {
      return res.status(400).json({
        success: false,
        message: "Keyword is required and must be in string format",
      });
    }

    // Create a regular expression for case-insensitive search
    const regEx = new RegExp(keyword, "i");

    // Construct the search query to match title, description, category, or brand
    const createSearchQuery = {
      $or: [
        { title: regEx },
        { description: regEx },
        { category: regEx },
        { brand: regEx },
      ],
    };

    // Search the products collection based on the query
    const searchResults = await Product.find(createSearchQuery);

    if (searchResults.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No products found matching your search criteria",
      });
    }

    // Return search results
    res.status(200).json({
      success: true,
      data: searchResults,
    });
  } catch (error) {
    console.error("Error while searching products:", error);
    res.status(500).json({
      success: false,
      message: "An error occurred while searching for products",
    });
  }
};

module.exports = { searchProducts };