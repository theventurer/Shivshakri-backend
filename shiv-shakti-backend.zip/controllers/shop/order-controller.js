const Razorpay = require("../../helpers/razorpay");
const Order = require("../../models/Order");
const Cart = require("../../models/Cart");
const Product = require("../../models/Product");
const twilio = require('twilio');
const crypto = require("crypto");

const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID, 
  process.env.TWILIO_AUTH_TOKEN
);

const createOrder = async (req, res) => {
  try {
    const {
      userId,
      cartItems,
      addressInfo,
      orderStatus = "pending",
      paymentStatus = "pending",
      totalAmount,
      orderDate,
      orderUpdateDate,
      cartId,
    } = req.body;

    if (!userId || !cartItems || !Array.isArray(cartItems) || cartItems.length === 0 || !totalAmount) {
      return res.status(400).json({
        success: false,
        message: "Missing required order information",
      });
    }
    // const razorpayOrder = await Razorpay.orders.create({
    //   amount: totalAmount * 100, // in paise
    //   currency: "INR",
    //   receipt: `receipt_${Date.now()}`,
    // });

    const newlyCreatedOrder = new Order({
      userId,
      cartId,
      cartItems,
      addressInfo,
      orderStatus,
      paymentMethod: "razorpay",
      paymentStatus,
      totalAmount,
      orderDate,
      orderUpdateDate,
      paymentId: cartId, //razorpay.id
    });

    await newlyCreatedOrder.save();

    res.status(201).json({
      success: true,
      razorpayOrderId: cartId, //razorpayOrder.id,
      orderId: newlyCreatedOrder._id,
      amount:  totalAmount, //razorpayOrder.amount,
      currency: "INR"//razorpayOrder.currency,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({
      success: false,
      message: "Some error occurred!",
    });
  }
};

const capturePayment = async (req, res) => {
  try {
    const { razorpay_payment_id, razorpay_order_id, razorpay_signature, orderId } = req.body;

    const generatedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");

    if (generatedSignature !== razorpay_signature) {
      return res.status(400).json({
        success: false,
        message: "Invalid Razorpay signature!",
      });
    }

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found!",
      });
    }

    const user = await UserActivation.findById(order.userId)

    order.paymentStatus = "paid";
    order.orderStatus = "confirmed";
    order.paymentId = razorpay_payment_id;

    for (let item of order.cartItems) {
      const product = await Product.findById(item.productId);
      if (!product) {
        return res.status(404).json({
          success: false,
          message: `Product with ID ${item.productId} not found.`,
        });
      }

      if (product.totalStock < item.quantity) {
        return res.status(400).json({
          success: false,
          message: `Not enough stock for product: ${product.title}`,
        });
      }

      product.totalStock -= item.quantity;
      await product.save();
    }

    if (order.cartId) {
      await Cart.findByIdAndDelete(order.cartId);
    }

    await order.save();
    
    // send sms of order
    try {
      const mobileNumber = user.mobileNumber
      const formattedNumber = mobileNumber.startsWith('+') 
        ? mobileNumber 
        : `+91${mobileNumber}`; // Assuming India as default country code
      
      if (process.env.NODE_ENV === 'development') {
        console.log(`DEVELOPMENT MODE: ORDER ID for ${mobileNumber} is ${orderId}`);
      }
      // Send the message via Twilio
      const message = await twilioClient.messages.create({
        body: `Thank you for shopping with Shiv Shakti Dresses! Your order (ID: ${orderId}) has been successfully placed. It will be delivered within 7–10 business days.`,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: formattedNumber
      });
      
      console.log(`SMS sent with SID: ${message.sid}`);
    } catch (error) {
      console.error('Error sending OTP via Twilio:', error);
      // In development, we'll still return true for testing purposes
      if (process.env.NODE_ENV === 'development') {
        console.log(`DEVELOPMENT MODE: OTP for ${mobileNumber} is ${otp}`);
      }
      // throw error;
    }

    res.status(200).json({
      success: true,
      message: "Payment captured and order confirmed",
      data: order,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({
      success: false,
      message: "Some error occurred!",
    });
  }
};

const getAllOrdersByUser = async (req, res) => {
  try {
    const { userId } = req.params;

    const orders = await Order.find({ userId });
    if (!orders.length) {
      return res.status(404).json({
        success: false,
        message: "No orders found!",
      });
    }

    res.status(200).json({
      success: true,
      data: orders,
    });
  } catch (e) {
    console.log(e);
    res.status(500).json({
      success: false,
      message: "Some error occurred!",
    });
  }
};

const getOrderDetails = async (req, res) => {
  try {
    const { id } = req.params;

    const order = await Order.findById(id);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found!",
      });
    }

    res.status(200).json({
      success: true,
      data: order,
    });
  } catch (e) {
    console.log(e);
    res.status(500).json({
      success: false,
      message: "Some error occurred!",
    });
  }
};

module.exports = {
  createOrder,
  capturePayment,
  getAllOrdersByUser,
  getOrderDetails,
};
