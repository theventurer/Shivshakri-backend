const jwt = require("jsonwebtoken");
const User = require("../../models/User");
const twilio = require('twilio');
require('dotenv').config();

// Create twilio client using environment variables
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID, 
  process.env.TWILIO_AUTH_TOKEN
);

// Helper function to generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Helper function to send OTP via Twilio
const sendOTP = async (mobileNumber, otp) => {
  try {
    // Format mobile number (ensure it has +country code)
    const formattedNumber = mobileNumber.startsWith('+') 
      ? mobileNumber 
      : `+91${mobileNumber}`; // Assuming India as default country code
    
    if (process.env.NODE_ENV === 'development') {
      console.log(`DEVELOPMENT MODE: OTP for ${mobileNumber} is ${otp}`);
      return true;
    }
    // Send the message via Twilio
    const message = await twilioClient.messages.create({
      body: `Your ShivShakti Dresses verification code is: ${otp}. Valid for 10 minutes. Do not share this OTP with anyone.`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: formattedNumber
    });
    console.log(`SMS sent with SID: ${message.sid}`);
    return true;
  } catch (error) {
    console.error('Error sending OTP via Twilio:', error);
    
    // In development, we'll still return true for testing purposes
    if (process.env.NODE_ENV === 'development') {
      console.log(`DEVELOPMENT MODE: OTP for ${mobileNumber} is ${otp}`);
      return true;
    }
    
    // In production, propagate the error
    throw error;
  }
};

// Unified request OTP function for both login and registration
const requestOTP = async (req, res) => {
  const { mobileNumber, userName, email } = req.body;

  if (!mobileNumber) {
    return res.status(400).json({
      success: false,
      message: "Mobile number is required",
    });
  }

  try {
    // Check if user already exists with this mobile number
    let user = await User.findOne({ mobileNumber });
    const now = new Date();

    // if (user && user.otpExpiry && user.otpExpiry > now) {
    //   const remainingMinutes = Math.ceil((user.otpExpiry - now) / 60000);
    //   return res.status(429).json({
    //     success: false,
    //     message: `OTP already sent. Please wait ${remainingMinutes} minute(s) before requesting again.`,
    //   });
    // }

    // Generate OTP
    const otp = generateOTP();
    const otpExpiry = new Date();
    otpExpiry.setMinutes(otpExpiry.getMinutes() + 10); // OTP valid for 10 minutes

    // If user doesn't exist, create a new one
    if (!user) {
      user = new User({
        userName: userName || mobileNumber, // Use provided userName or mobileNumber as fallback
        mobileNumber,
        email,
        otp,
        otpExpiry,
      });
    } else {
      // Update existing user with new OTP
      user.otp = otp;
      user.otpExpiry = otpExpiry;
      
      // Update userName and email if provided
      if (userName) user.userName = userName;
      if (email) user.email = email;
    }

    await user.save();
    
    // Send OTP
    await sendOTP(mobileNumber, otp);

    res.status(200).json({
      success: true,
      message: "OTP sent successfully to your mobile number",
      userId: user._id,
      isNewUser: !user.isVerified,
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({
      success: false,
      message: "Some error occurred",
    });
  }
};

// Unified verify OTP function for both login and registration
const verifyOTP = async (req, res) => {
  const { userId, otp } = req.body;

  if (!userId || !otp) {
    return res.status(400).json({
      success: false,
      message: "User ID and OTP are required",
    });
  }

  try {
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    const now = new Date();
    
    if (user.otp !== otp) {
      return res.json({
        success: false,
        message: "Invalid OTP",
      });
    }

    if (now > user.otpExpiry) {
      return res.json({
        success: false,
        message: "OTP has expired. Please request a new one",
      });
    }

    const isNewUser = !user.isVerified;
    
    // Mark user as verified and clear OTP
    user.isVerified = true;
    user.otp = undefined;
    user.otpExpiry = undefined;
    await user.save();

    // Generate JWT token
    const token = jwt.sign(
      {
        id: user._id,
        role: user.role,
        mobileNumber: user.mobileNumber,
        userName: user.userName,
      },
      process.env.CLIENT_SECRET_KEY,
      { expiresIn: "60m" }
    );

    res.cookie("token", token, { httpOnly: true, secure: false }).json({
      success: true,
      message: isNewUser ? "Registration completed successfully" : "Logged in successfully",
      isNewUser,
      user: {
        mobileNumber: user.mobileNumber,
        role: user.role,
        id: user._id,
        userName: user.userName,
        email: user.email,
      },
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({
      success: false,
      message: "Some error occurred",
    });
  }
};

// Logout user
const logoutUser = (req, res) => {
  res.clearCookie("token").json({
    success: true,
    message: "Logged out successfully!",
  });
};

// Auth middleware
const authMiddleware = async (req, res, next) => {
  const token = req.cookies.token;
  if (!token)
    return res.status(401).json({
      success: false,
      message: "Unauthorized user!",
    });

  try {
    const decoded = jwt.verify(token, process.env.CLIENT_SECRET_KEY);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({
      success: false,
      message: "Unauthorized user!",
    });
  }
};

module.exports = {
  requestOTP,
  verifyOTP,
  logoutUser,
  authMiddleware
};